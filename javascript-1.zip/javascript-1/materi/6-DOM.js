// Select berdasarkan Tag
document.getElementsByTagName('h1');

// Select berdasarkan ID
document.getElementById('isParagraf');

// Select berdasarkan Class
document.getElementsByClassName('is-paragraf');


// ketika ingin select berdasarkan class/tag harus menggunakan index [...] atau di looping
document.getElementsByClassName('is-paragraf')[0];

document.getElementsByTagName('h1')[0];

// dan lain-lain
