var nama;
let nama;
const nama;

// cara menggunakan Variable
// tidak disarankan menggunakan var untuk membuat variable
// cara lama dan banyak masalah
var nama = 'Sabiq Muhammad'; 

let nama = 'Sabiq Muhammad'; // let: nilai bisa dideklarasikan ulang/diubah
const nama = 'Sabiq Muhammad'; // const: tidak bisa dideklarasikan ulang/diubah
