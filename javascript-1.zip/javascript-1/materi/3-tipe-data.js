/** STRING/TEXT
 * 'sabiq muhammad'
 */
let nama = 'Sabiq Muhammad';
let umur = '19';

// cara mengakses
nama;




/** Number
 * 19
 */
let umur = 19;

// cara mengakses
umur;



/** BOOLEAN
 * true
 * false
 */
let javaScriptItuSeru = true;
let sayaOrangKaya = false;

// cara mengakses
javaScriptItuSeru;


/** ARRAY
 * ['pesawat', 'mobil', 'motor']
 */
let kendaraan = ['pesawat', 'mobil', 'motor'];

// cara mengakses
kendaraan[0] // pesawat




/** OBJECT
 * { nama: 'sabiq', umur: 19 }
 */
let dataPribadi = { nama: 'sabiq', umur: 19 } ;
// atau
let dataPribadi2 = {
  nama: 'sabiq',
  umur: 19,
};

// cara mengakses
dataPribadi2.nama // sabiq


// dan lain lain
