// ====== operator + ======
let pertambahan = 1 + 1;
// const pertambahan = 1 + 1;

// atau bisa digunakan untuk penggabung
let nama = 'sabiq muhammad';
let umur = 19;
let domisili = 'Citayam, Bogor';

let dataPribadi = 'nama saya: ' + nama + ' umur saya: ' + umur + ' domisili saya: ' + domisili;
console.log(dataPribadi);
// atau bisa menggunakan


// ======= operator - ======
let pengurangan = 1 - 1;
// const pengurangan = 1 - 1;