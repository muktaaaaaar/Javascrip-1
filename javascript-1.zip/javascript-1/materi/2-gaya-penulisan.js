let camelCase;
let snake_case; 
let PascalCase;
// let kebab-case; // tidak bisa digunakan di javascript
let ALL_CAPS;

// dan lain lain

// source https://www.konsepkoding.com/2020/05/5-gaya-penulisan-pemrograman.html